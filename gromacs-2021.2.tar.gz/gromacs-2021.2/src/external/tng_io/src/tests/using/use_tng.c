#include "tng/tng_io.h"

void test_tng(void)
{
    tng_trajectory_t data;
    char             buf[256];
    tng_version(data, buf, 256);
}
